# Google Analytics and Search Console Integration Guide

This document provides details on how Google Analytics 4 and Google Search Console have been integrated with the how-toguides.com website.

## Google Analytics 4 Integration

### Implementation Details

- **Measurement ID**: G-1PLJ849SK4
- **Implementation Method**: Next.js Script component with 'afterInteractive' strategy
- **Location**: `/src/components/Analytics.tsx` component integrated in the root layout

### Tracking Features Implemented

1. **Page Views**
   - Automatic tracking of all page views
   - Includes path, search parameters, and page title
   - Updates when routes change using Next.js navigation hooks

2. **Lead Generation Form Tracking**
   - Form submission events for all lead capture forms
   - Captures form ID, guide name, and signup source
   - Tracks both inline forms and popup forms

3. **Guide Module Interaction Tracking**
   - Tracks clicks on guide module links
   - Distinguishes between free and premium content
   - Captures module title and associated guide

4. **CTA Button Tracking**
   - Monitors clicks on call-to-action buttons
   - Records CTA text and location
   - Associates with the current guide being viewed

5. **Download Tracking**
   - Tracks lead magnet downloads
   - Records download type and associated guide

### Data Attributes Required

For proper event tracking, the following data attributes should be added to elements:

- `data-form-id`: Unique identifier for each form
- `data-guide-name`: Name of the guide associated with the form
- `data-signup-source`: Source of the signup (sidebar, popup, inline, etc.)

## Google Search Console Integration

### Current Setup

- **Verification Method**: TXT record in DNS
- **Backup Method**: HTML meta tag placeholder included in Analytics component

### Verification Status

The TXT record verification has been completed by the site owner. The HTML meta tag is included as a backup method but requires the verification code to be added.

## Next Steps

1. **Verify Analytics Installation**:
   - After deployment, check Google Analytics real-time reports to confirm data is being received
   - Test each event type to ensure proper tracking

2. **Complete Search Console Setup**:
   - Submit sitemap.xml through Search Console
   - Set preferred domain version (www vs non-www)
   - Monitor for any indexing issues

3. **Future Enhancements**:
   - Consider implementing enhanced ecommerce tracking if monetization is added
   - Set up custom audiences based on guide interactions
   - Create custom reports for lead generation performance
